package SOLID;

public interface PaymentType {

  double calculate(double amount);
}
