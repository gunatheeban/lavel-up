package oop.AbstractionProblems.SubscriptionManagementSystem;

public interface Tax {

  Country getCountry();
  double taxPercentage();

}
