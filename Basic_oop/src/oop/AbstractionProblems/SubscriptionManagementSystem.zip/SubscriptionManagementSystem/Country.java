package oop.AbstractionProblems.SubscriptionManagementSystem;

public enum Country {
  SRI_LANKA, US, UAE
}
