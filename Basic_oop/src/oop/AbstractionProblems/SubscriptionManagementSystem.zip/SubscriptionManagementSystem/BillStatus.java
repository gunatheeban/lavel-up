package oop.AbstractionProblems.SubscriptionManagementSystem;

public enum BillStatus {
  SUCCESS, FAILED
}
