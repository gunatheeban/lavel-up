package oop.AbstractionProblems.SubscriptionManagementSystem;

public enum PlanType {
  BASIC, STANDARD, PREMIUM
}
