package SOLID.UserService;

public class Notification {

  public void send(String email) {
    System.out.println("Sending welcome email to " + email);
  }
}
