package SOLID.UserService;

public class Audit {

  public void log() {
    System.out.println("Writing audit log for user registration");
  }
}
