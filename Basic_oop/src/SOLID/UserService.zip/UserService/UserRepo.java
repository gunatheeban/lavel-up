package SOLID.UserService;

public class UserRepo {

  public void save() {
    System.out.println("Saving user to database");
  }
}
