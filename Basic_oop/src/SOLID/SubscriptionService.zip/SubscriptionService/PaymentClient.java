package SOLID.SubscriptionService;

public abstract class PaymentClient {

  abstract void charge(double amount);

}
