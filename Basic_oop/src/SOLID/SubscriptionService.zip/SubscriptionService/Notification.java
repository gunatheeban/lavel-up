package SOLID.SubscriptionService;

public abstract class Notification {

  abstract void send();
}
