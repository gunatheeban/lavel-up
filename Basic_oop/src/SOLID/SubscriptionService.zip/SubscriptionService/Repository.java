package SOLID.SubscriptionService;

public interface Repository {

  void save(Object o);

}
