package SOLID.OrderService;

public enum PaymentType {
  CARD, UPI, CASH
}
