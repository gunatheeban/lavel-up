package SOLID.OrderService;

public interface DiscountPolicy {

  double calculateDiscount(double amount);

}
