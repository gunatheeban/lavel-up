package SOLID.OrderService;

public enum CustomerType {
  REGULAR, PREMIUM
}
