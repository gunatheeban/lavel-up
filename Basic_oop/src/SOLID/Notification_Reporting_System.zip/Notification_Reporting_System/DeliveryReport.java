package SOLID.Notification_Reporting_System;

public interface DeliveryReport {

  void generateDeliveryReport();

}
