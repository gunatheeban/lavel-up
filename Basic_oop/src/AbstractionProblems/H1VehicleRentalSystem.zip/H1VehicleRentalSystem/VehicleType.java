package AbstractionProblems.H1VehicleRentalSystem;

public enum VehicleType {
  CAR, TRUCK, MOTOR_BIKE
}
