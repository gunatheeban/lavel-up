package AbstractionProblems.H1VehicleRentalSystem;

public enum DiscountType {
  LOYALTY, LONG_STAY, VEHICLE_SPECIFIC
}
